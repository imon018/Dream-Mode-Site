# Cleanup pass — what changed and why

## 1. console.log removed from production code (228 statements, 71 files)
All standalone `console.log(...)` debug statements removed. `console.error`
and `console.warn` calls were left untouched (they're legitimate error/
warning logs). Two `console.log(err)` calls inside `.catch()` in
passkeyService.js were upgraded to `console.error(err)` instead of removed,
since they're real error handling.

Every touched file was checked for balanced braces/parens/brackets after
the edit, and plain .js files were run through `node --check` — no syntax
errors introduced.

## 2. Delivery charge no longer duplicated in 3 places
Added `DEFAULT_DELIVERY_CHARGE = 80` to `src/utils/constants.js`.
Checkout.jsx, admin/AddOrder.jsx, and PublicLandingPage.jsx now import and
use this constant instead of each having their own hardcoded
`useState(80)`. Changing the default delivery charge in the future now
only requires editing one file.

## How to apply
Copy the `src/` folder from this package into your project root,
overwriting the matching files (paths line up exactly with your existing
structure — nothing new is created, nothing is renamed).
