import {
  useEffect,
  useMemo,
  useState,
} from "react";

import { DEFAULT_DELIVERY_CHARGE } from "../utils/constants";

import {
  useNavigate,
  useParams,
} from "react-router-dom";

import {
  FiHome,
  FiFileText,
  FiMap,
  FiMapPin,
  FiUser,
  FiPhone,
  FiX,
  FiGift,
  FiCreditCard,
  FiChevronDown,
  FiChevronUp,
  FiTruck,
} from "react-icons/fi";

import {
  FaFacebookMessenger,
  FaWhatsapp,
} from "react-icons/fa";


import SEO from "../seo/SEO";

import {
  getLandingPageBySlug,
  incrementLandingOrders,
} from "../services/landingPageService";

import { createOrder } from "../services/orderService";

import {
  errorToast,
} from "../components/ui/Toast";

import RelatedProducts from "../components/RelatedProducts";

import useSettings from "../hooks/useSettings";


const MESSENGER_LINK = "https://m.me/61560486613695";

const BKASH_NUMBER = "01628464209";
const NAGAD_NUMBER = "01628464209";


export default function PublicLandingPage(){



const navigate = useNavigate();

const { slug } = useParams();

const { settings } = useSettings();

const [landing,setLanding] = useState(null);

const [loading,setLoading] = useState(true);

const [ordering, setOrdering] = useState(false);

const [quantity,setQuantity] = useState(1);

const [deliveryCharge, setDeliveryCharge] = useState(DEFAULT_DELIVERY_CHARGE);

// ---------- PAYMENT METHOD ----------

const [paymentOpen, setPaymentOpen] = useState(true);

const [paymentMethod, setPaymentMethod] = useState("COD");

const [bkashNumber, setBkashNumber] = useState("");
const [bkashTransactionId, setBkashTransactionId] = useState("");

const [nagadNumber, setNagadNumber] = useState("");
const [nagadTransactionId, setNagadTransactionId] = useState("");

const [activeImage,setActiveImage] = useState(null);

const [fullscreen,setFullscreen] = useState(false);

const [formData, setFormData] = useState({

  name: "",
  phone: "",
  address: "",
  thana: "",
  district: "",
  notes: "",
});

// ---------- AUTO DELIVERY CHARGE BY DISTRICT ----------
// If the customer types a district other than Dhaka, switch the
// delivery charge to the "Outside Dhaka" rate automatically. If
// they type Dhaka (or clear the field), switch back to the
// "Dhaka City" rate. A manual pick from the dropdown still works
// normally since this only reacts to district changes.

useEffect(() => {

  const district = formData.district.trim().toLowerCase();

  if (!district) return;

  const isDhaka =
    district.includes("dhaka") ||
    district.includes("ঢাকা");

  setDeliveryCharge(isDhaka ? 80 : 150);

}, [formData.district]);

// Moved above the early return, and memoized so it doesn't
// produce a brand-new array reference on every render.
const images = useMemo(() => {

  if (!landing) return [];

  return landing.heroImages?.length
    ? landing.heroImages
    : landing.heroImage
    ? [landing.heroImage]
    : [];

}, [landing]);


  

useEffect(() => {

  async function loadLanding() {
    setLoading(true);

    try {

      const data =
        await getLandingPageBySlug(slug);

      if (!data) {

        setLanding(null);

        return;

      }

      setLanding(data);

      const imgs =
        data.heroImages?.length
          ? data.heroImages
          : data.heroImage
          ? [data.heroImage]
          : [];

      if (imgs.length) {

        setActiveImage(imgs[0]);

      }

    }

    catch (error) {


}

finally {

  setLoading(false);

}

}

loadLanding();

}, [slug]);

  

  useEffect(() => {
  if (images.length <= 1) return;

  const interval = setInterval(() => {
    setActiveImage((prev) => {
      const currentIndex = images.indexOf(prev || images[0]);
      const nextIndex = (currentIndex + 1) % images.length;
      return images[nextIndex];
    });
  }, 3000);

  return () => clearInterval(interval);
}, [images]);



if (loading) {

  return (

    <div
      className="
      min-h-screen
      flex
      items-center
      justify-center
      bg-[#FAF7F2]
      "
    >

      <div
        className="
        text-xl
        font-bold
        text-purple-700
        "
      >
        Loading...
      </div>

    </div>

  );

}


  
if(!landing){


return (

<div
className="
min-h-screen
flex
items-center
justify-center
bg-gray-100
"
>

<div
className="
bg-white
rounded-lg
p-8
shadow
"
>

<h2
className="
text-xl
font-bold
"
>

Landing Page পাওয়া যায়নি

</h2>


</div>


</div>

);


}






const discount =

landing.offerPrice > 0 &&
landing.price > 0

?

Math.round(

(

(landing.price - landing.offerPrice)

/

landing.price

)

*100

)

:

0;


// এই ল্যান্ডিং পেজে যদি themeColor সেট করা না থাকে (পুরাতন ল্যান্ডিং পেজ)
// তাহলে আগের ডিফল্ট বেগুনী (purple-700) কালারই ব্যবহার হবে,
// যাতে বিদ্যমান পেজের UI ভেঙে না যায়।
// themeMode === "gradient" হলে দুইটা কালার মিক্স করে gradient দেখানো হবে।

const themeColor =
  landing.themeColor || "#7e22ce";

const isGradientTheme =
  landing.themeMode === "gradient" &&
  landing.themeColorTo;

const gradientCSS =
  isGradientTheme
    ? `linear-gradient(${landing.themeGradientDirection || "to right"}, ${themeColor}, ${landing.themeColorTo})`
    : null;

// ব্যাকগ্রাউন্ড হিসেবে ব্যবহারের জন্য (যেমন ব্যানার, চেকমার্ক বৃত্ত, বাটন)

const themeBgStyle =
  isGradientTheme
    ? { backgroundImage: gradientCSS }
    : { backgroundColor: themeColor };

// টেক্সট কালার হিসেবে ব্যবহারের জন্য (গ্রেডিয়েন্ট হলে gradient text)

const themeTextStyle =
  isGradientTheme
    ? {
        backgroundImage: gradientCSS,
        WebkitBackgroundClip: "text",
        backgroundClip: "text",
        color: "transparent",
      }
    : { color: themeColor };

// hex কালারকে rgba-তে রূপান্তর করার জন্য (হালকা টিন্ট ব্যাকগ্রাউন্ড/বর্ডার/ফোকাস রিং-এর জন্য)

const themeAlpha = (alpha) => {

  const hex =
    themeColor.replace("#","");

  const normalized =
    hex.length === 3
      ? hex.split("").map(c=>c+c).join("")
      : hex;

  const value =
    parseInt(normalized, 16);

  if (isNaN(value)) {
    return `rgba(126, 34, 206, ${alpha})`;
  }

  const r = (value >> 16) & 255;
  const g = (value >> 8) & 255;
  const b = value & 255;

  return `rgba(${r}, ${g}, ${b}, ${alpha})`;

};

const handleThemeFocus = (e) => {

  e.target.style.borderColor = themeColor;
  e.target.style.boxShadow =
    `0 0 0 2px ${themeAlpha(0.3)}`;

};

const handleThemeBlur = (e) => {

  e.target.style.borderColor = "";
  e.target.style.boxShadow = "";

};


const handleChange = (e) => {

  const { name, value } = e.target;

  setFormData((prev) => ({

    ...prev,

    [name]: value,

  }));

};
  


  const productPrice =
  landing.offerPrice > 0
    ? landing.offerPrice
    : landing.price;

const subTotal =
  productPrice * quantity;

const total =
  subTotal + deliveryCharge;


  

const formattedText = (text)=>{


if(!text)

return "";



return text
.replace(/\\n/g,"\n");


};








return (
<>
  <SEO
    title={landing.title}
    description={
      landing.description ||
      landing.heroDescription ||
      `${landing.title} available at ${landing.storeName || settings?.storeName || ""}.`
    }
    image={
      landing.heroImages?.[0] ||
      landing.heroImage
    }
    url={`/landing/${landing.slug}`}
    type="product"
    product={{
      id: landing.id,
      name: landing.title,
      description:
        landing.description ||
        landing.heroDescription,
      images:
        landing.heroImages,
      image:
        landing.heroImage,
      price:
        landing.offerPrice > 0
          ? landing.offerPrice
          : landing.price,
      stock: 999
    }}
  />

<div
className="
min-h-screen
bg-[#FAF7F2]
"
>



<div className="w-full max-w-none">

















{/* PREVIEW AREA */}



<div
className="
mt-0
bg-[#FAF7F2]
w-full
"
>



<div
className="
pt-0
"
>






<div
style={themeBgStyle}
className="
text-white
h-10
px-3
flex
items-center
justify-center
gap-2
text-xs
font-semibold
whitespace-nowrap
"
>

<FiGift className="text-base shrink-0"/>

<span>
আজই অর্ডার করুন, ক্যাশ অন ডেলিভারি!
</span>

</div>

  

{/* IMAGE GALLERY */}



<div
className="
relative
"
>



{
images.length > 0 && (


<>


<img

src={
activeImage || images[0]
}

alt="product"

onClick={()=>setFullscreen(true)}

className="
w-full
h-auto
object-contain
cursor-pointer
"

/>



{
discount > 0 && (

<div
className="
absolute
top-3
right-3
z-20
w-12
text-center
"
>

<div
className="
relative
overflow-visible
rounded-t-md
bg-transparent
border
border-amber-300
shadow-none
"
>

<div className="py-2">
<div style={themeTextStyle} className="text-lg font-black leading-none">
{discount}%
</div>

<div style={themeTextStyle} className="text-[11px] font-bold mt-1">
OFF
</div>
</div>

{/* Bottom Ribbon */}

  
<div className="relative h-3">

<div
className="
absolute
left-0
right-0
top-0
h-[2px]
bg-amber-300
"
/>

<div
className="
absolute
left-1/2
top-[-1px]
-translate-x-1/2
w-0
h-0
border-l-[24px]
border-r-[24px]
border-t-[14px]
border-l-transparent
border-r-transparent
border-t-amber-300
"
/>

</div>

</div>

</div>

)
}



</>


)

}





</div>



 {/* PRODUCT INFO CARD */}

<div
className="
mt-6
bg-gray-50
rounded-lg
p-5
"
>



{/* THUMBNAILS */}


{

images.length > 1 && (


<div
className="
flex
gap-3
mt-4
overflow-x-auto
pb-0
[-ms-overflow-style:none]
[scrollbar-width:none]
[&::-webkit-scrollbar]:hidden
"
>


{

images.map((img,index)=>(


<img

key={index}

src={img}

alt="thumb"

onClick={()=>setActiveImage(img)}

className={`
w-20
h-20
object-cover
rounded-md
cursor-pointer


`}

/>



))


}



</div>


)

}





 

  {/*  HERO TITLE */}


<h2
style={themeTextStyle}
className="
text-sm
font-bold
mt-2
"
>

{formattedText(landing.heroTitle)}

</h2>





{/* PRODUCT NAME */}

<h1
className="
text-3xl
font-black
mt-3
text-gray-900
"
>

{landing.title}

</h1>








{/* HERO DESCRIPTION */}


<div
className="
mt-5
text-gray-600
leading-8
whitespace-pre-line
"
>

{
formattedText(landing.heroDescription)
.split("\n")
.map((line,index)=>(
<div
key={index}
className="
flex
items-center
gap-3
mb-3
"
>

<div
style={themeBgStyle}
className="
w-4
h-4
rounded-full
text-white
flex
items-center
justify-center
text-xs
font-bold
shrink-0
"
>
✓
</div>


<span>
{line}
</span>


</div>
))
}

</div>








{/* PRICE SECTION */}

<div
className="
mt-8
flex
items-center
gap-4
flex-wrap
"
>

{
landing.price > 0 && landing.offerPrice > 0 && landing.offerPrice < landing.price

?

<>

<span
style={themeTextStyle}
className="
text-2xl
font-black
"
>
৳{landing.offerPrice}
</span>


<span
className="
text-base
text-gray-400
font-medium
line-through
"
>
৳{landing.price}
</span>


{
discount > 0 && (

<span
className="
px-4
py-2
rounded-lg
font-bold
text-red-600
bg-white/40
backdrop-blur-md
border
border-white/60
shadow-lg
"
>
{discount}% OFF
</span>

)

}

</>


:

landing.price > 0

?

<span
style={themeTextStyle}
className="
text-4xl
font-black
"
>
৳{landing.price}
</span>


:

null

}

</div>










{/* QUANTITY */}



<div
className="
mt-5
mb-0
border
border-gray-200
rounded-lg
px-4
py-2
flex
justify-between
items-center
"
>


<span
className="
font-black
text-lg
"
>

Quantity

</span>




<div
className="
flex
items-center
gap-5
"
>


<button

onClick={()=>{

if(quantity>1)

setQuantity(quantity-1)

}}

className="
w-6
h-6
rounded-lg
bg-gray-200
font-bold
"
>

-

</button>




<span
className="
font-black
text-xl
"
>

{quantity}

</span>




<button

onClick={()=>setQuantity(quantity+1)}

style={themeBgStyle}

className="
w-6
h-6
rounded-lg
text-white
font-bold
"
>

+

</button>



</div>


</div>



</div>


</div>


<div
className="
border-t
border-gray-200
"
></div>



{/* ORDER FORM */}



<div
className="
bg-gray-50
pt-5
px-5
pb-5
"
>



<h2
className="
text-2xl
font-black
text-center
mb-5
"
>
অর্ডার ফর্ম
</h2>





{
landing.orderForm?.collectName && (

<div className="relative mb-3">

<FiUser
className="
absolute
left-3
top-1/2
-translate-y-1/2
text-gray-400
"
/>

<input

name="name"

value={formData.name}

onChange={handleChange}

onFocus={handleThemeFocus}

onBlur={handleThemeBlur}

placeholder="আপনার নাম"
  
className="
w-full
pl-10
pr-4
py-3
border
rounded-lg
focus:outline-none
"
/>

</div>

)
}




{
landing.orderForm?.collectPhone && (

<div className="relative mb-3">

<FiPhone
className="
absolute
left-3
top-1/2
-translate-y-1/2
text-gray-400
"
/>

<input

name="phone"

value={formData.phone}

onChange={handleChange}

onFocus={handleThemeFocus}

onBlur={handleThemeBlur}

placeholder="ফোন নাম্বার"
  
className="
w-full
pl-10
pr-4
py-3
border
rounded-lg
focus:outline-none
"
/>

</div>

)
}




{
landing.orderForm?.collectAddress && (

<div className="relative mb-3">

<FiHome
className="
absolute
left-3
top-4
text-gray-400
"
/>

<textarea

name="address"

value={formData.address}

onChange={handleChange}

onFocus={handleThemeFocus}

onBlur={handleThemeBlur}

placeholder="আপনার ঠিকানা"
  
rows="3"
className="
w-full
pl-10
pr-4
py-3
border
rounded-lg
resize-none
focus:outline-none
"
/>

</div>

)
}






{
landing.orderForm?.collectCity && (

<>
  
<div className="relative mb-3">

<FiMap
className="
absolute
left-3
top-1/2
-translate-y-1/2
text-gray-400
"
/>

<input

name="thana"

value={formData.thana}

onChange={handleChange}

onFocus={handleThemeFocus}

onBlur={handleThemeBlur}

placeholder="থানা"
  
className="
w-full
pl-10
pr-4
py-3
border
rounded-lg
focus:outline-none
"
/>

</div>


  

<div className="relative mb-3">

<FiMapPin
className="
absolute
left-3
top-1/2
-translate-y-1/2
text-gray-400
"
/>

<input

name="district"

value={formData.district}

onChange={handleChange}

onFocus={handleThemeFocus}

onBlur={handleThemeBlur}

placeholder="জেলা"
  
className="
w-full
pl-10
pr-4
py-3
border
rounded-lg
focus:outline-none
"
/>

</div>

</>

)
}

  



{
landing.orderForm?.collectNotes && (
  
<div className="relative mt-3">

<FiFileText
className="
absolute
left-3
top-4
text-gray-400
"
/>

<textarea

name="notes"

value={formData.notes}

onChange={handleChange}

onFocus={handleThemeFocus}

onBlur={handleThemeBlur}

placeholder="অতিরিক্ত নোট (যদি থাকে)"
  
rows="3"
className="
w-full
pl-10
pr-4
py-3
border
rounded-lg
resize-none
focus:outline-none
"
/>

</div>

)
}






</div>










{/* PRODUCT DESCRIPTION */}



<div
className="
border-t
border-gray-200
"
></div>

<div
className="
bg-gray-50
px-5
py-5
"
>



<h2
className="
text-2xl
font-black
text-center
mb-5
"
>

পণ্যের বিবরণ

</h2>





<div
className="
text-gray-700
leading-8
whitespace-pre-line
bg-white
border
border-gray-200
rounded-lg
p-5
"
>

{formattedText(
landing.description
)}

</div>



  
<div
className="
border-t
border-gray-200
"
/></div>

  



{/* DELIVERY CHARGE */}

<div
className="
bg-gray-50
px-5
pb-5
"
>

<div
className="
bg-white
border
border-gray-200
rounded-lg
p-5
"
>

<h2
className="
text-xl
font-bold
mb-4
"
>
ডেলিভারি চার্জ
</h2>

<select

value={deliveryCharge}

onChange={(e)=>
setDeliveryCharge(
Number(e.target.value)
)
}

className="
w-full
border
rounded-lg
px-4
py-3
outline-none
"

>

<option value={80}>
ঢাকা - ৳৮০
</option>

<option value={120}>
ঢাকা সাব এরিয়া - ৳১২০
</option>

<option value={150}>
ঢাকার বাইরে - ৳১৫০
</option>

</select>

</div>

</div>





{/* ORDER SUMMARY */}

<div
className="
bg-gray-50
px-5
pb-5
"
>

<div
className="
bg-white
border
border-gray-200
rounded-lg
p-5
"
>

<h2
className="
text-xl
font-bold
mb-4
"
>

অর্ডার বিবরণ

</h2>

<div className="space-y-3">

<div className="flex justify-between">

<span>
Sub Total
</span>

<span>
৳{subTotal}
</span>

</div>

<div className="flex justify-between">

<span>
Delivery Charge
</span>

<span>
৳{deliveryCharge}
</span>

</div>

<hr/>

<div
style={themeTextStyle}
className="
flex
justify-between
text-lg
font-black
"
>

<span>
Total
</span>

<span>
৳{total}
</span>

</div>

</div>

</div>

</div>

  


{/* PAYMENT METHOD */}


<div
className="
bg-gray-50
px-5
pb-5
"
>

<div
className="
bg-white
border
border-gray-200
rounded-lg
p-5
"
>


<button

type="button"

onClick={()=>setPaymentOpen(!paymentOpen)}

className="
w-full
flex
items-center
justify-between
"
>

<span
className="
flex
items-center
gap-2
text-xl
font-bold
"
>

<FiCreditCard />
Payment Method

</span>


{
paymentOpen
?
<FiChevronUp className="text-gray-500" />
:
<FiChevronDown className="text-gray-500" />
}


</button>




{
paymentOpen && (

<div
className="
mt-4
space-y-3
"
>


{/* BKASH */}

<div

onClick={()=>setPaymentMethod("bKash")}

className={`
flex
items-center
gap-3
p-4
rounded-lg
border
cursor-pointer
transition
${
paymentMethod === "bKash"
?
"border-amber-500 bg-amber-50"
:
"border-gray-200 bg-white hover:border-gray-300"
}
`}

>

<span
className={`
w-5
h-5
rounded-full
border-2
flex-shrink-0
flex
items-center
justify-center
${
paymentMethod === "bKash"
?
"border-amber-500"
:
"border-gray-300"
}
`}
>

{
paymentMethod === "bKash" && (
<span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
)
}

</span>


<span
className="
w-10
h-10
rounded-lg
overflow-hidden
flex-shrink-0
bg-white
border
border-gray-100
"
>
<img
src="/payments/bkash-logo.png"
alt="bKash"
className="w-full h-full object-contain"
/>
</span>


<div>

<p className="font-bold">
bKash Payment
</p>

<p className="text-sm text-gray-500">
Pay securely using bKash
</p>

</div>


</div>




{
paymentMethod === "bKash" && (

<div
className="
p-5
rounded-lg
bg-gray-50
border
border-gray-200
"
>

<p
className="
font-bold
text-green-600
mb-4
"
>
You need to send us ৳ {total}
</p>


<p className="text-sm text-gray-600 mb-1">
Account Type: <span className="font-semibold text-gray-800">Personal</span>
</p>

<p className="text-sm text-gray-600 mb-4">
Account Number: <span className="font-semibold text-gray-800">{BKASH_NUMBER}</span>
</p>


<hr className="border-gray-200 mb-4" />


<label className="block text-sm text-gray-600 mb-1">
Your bKash Account Number
</label>

<input

value={bkashNumber}

onChange={e=>setBkashNumber(e.target.value)}

placeholder="01XXXXXXXXX"

className="
w-full
mb-4
px-4
py-3
border
border-gray-300
rounded-lg
focus:outline-none
focus:border-amber-500
bg-white
"
/>


<label className="block text-sm text-gray-600 mb-1">
Your bKash Transaction ID
</label>

<input

value={bkashTransactionId}

onChange={e=>setBkashTransactionId(e.target.value)}

placeholder="Ex: 2M7A5"

className="
w-full
px-4
py-3
border
border-gray-300
rounded-lg
focus:outline-none
focus:border-amber-500
bg-white
"
/>


</div>

)
}




{/* NAGAD */}

<div

onClick={()=>setPaymentMethod("Nagad")}

className={`
flex
items-center
gap-3
p-4
rounded-lg
border
cursor-pointer
transition
${
paymentMethod === "Nagad"
?
"border-amber-500 bg-amber-50"
:
"border-gray-200 bg-white hover:border-gray-300"
}
`}

>

<span
className={`
w-5
h-5
rounded-full
border-2
flex-shrink-0
flex
items-center
justify-center
${
paymentMethod === "Nagad"
?
"border-amber-500"
:
"border-gray-300"
}
`}
>

{
paymentMethod === "Nagad" && (
<span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
)
}

</span>


<span
className="
w-10
h-10
rounded-lg
overflow-hidden
flex-shrink-0
bg-white
border
border-gray-100
"
>
<img
src="/payments/nagad-logo.png"
alt="Nagad"
className="w-full h-full object-contain"
/>
</span>


<div>

<p className="font-bold">
Nagad Payment
</p>

<p className="text-sm text-gray-500">
Pay securely using Nagad
</p>

</div>


</div>




{
paymentMethod === "Nagad" && (

<div
className="
p-5
rounded-lg
bg-gray-50
border
border-gray-200
"
>

<p
className="
font-bold
text-green-600
mb-4
"
>
You need to send us ৳ {total}
</p>


<p className="text-sm text-gray-600 mb-1">
Account Type: <span className="font-semibold text-gray-800">Personal</span>
</p>

<p className="text-sm text-gray-600 mb-4">
Account Number: <span className="font-semibold text-gray-800">{NAGAD_NUMBER}</span>
</p>


<hr className="border-gray-200 mb-4" />


<label className="block text-sm text-gray-600 mb-1">
Your Nagad Account Number
</label>

<input

value={nagadNumber}

onChange={e=>setNagadNumber(e.target.value)}

placeholder="01XXXXXXXXX"

className="
w-full
mb-4
px-4
py-3
border
border-gray-300
rounded-lg
focus:outline-none
focus:border-amber-500
bg-white
"
/>


<label className="block text-sm text-gray-600 mb-1">
Your Nagad Transaction ID
</label>

<input

value={nagadTransactionId}

onChange={e=>setNagadTransactionId(e.target.value)}

placeholder="Ex: 2M7A5"

className="
w-full
px-4
py-3
border
border-gray-300
rounded-lg
focus:outline-none
focus:border-amber-500
bg-white
"
/>


</div>

)
}




{/* COD */}

<div

onClick={()=>setPaymentMethod("COD")}

className={`
flex
items-center
gap-3
p-4
rounded-lg
border
cursor-pointer
transition
${
paymentMethod === "COD"
?
"border-amber-500 bg-amber-50"
:
"border-gray-200 bg-white hover:border-gray-300"
}
`}

>

<span
className={`
w-5
h-5
rounded-full
border-2
flex-shrink-0
flex
items-center
justify-center
${
paymentMethod === "COD"
?
"border-amber-500"
:
"border-gray-300"
}
`}
>

{
paymentMethod === "COD" && (
<span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
)
}

</span>


<span
className="
w-10
h-10
rounded-lg
bg-gray-100
flex
items-center
justify-center
text-amber-500
flex-shrink-0
"
>
<FiTruck size={20} />
</span>


<div>

<p className="font-bold">
Cash on Delivery (COD)
</p>

<p className="text-sm text-gray-500">
Pay when you receive
</p>

</div>


</div>


</div>

)
}


</div>

</div>


  

{/* OUR PROMISE */}

<div
style={{
  backgroundColor: themeAlpha(0.15),
  borderColor: themeAlpha(0.15),
}}
className="
mx-5
backdrop-blur-xl
border-t
rounded-lg
px-3
py-1
shadow-none
"
>


<div
className="
flex
items-start
gap-4
"
>




<div className="flex gap-3">

<div
style={{ backgroundColor: themeAlpha(0.12) }}
className="
w-8
h-8
rounded-lg
flex
items-center
justify-center
shrink-0
text-sm
"
>
🛡️
</div>

<div className="flex-1">

<h2
style={themeTextStyle}
className="
text-base
font-black
whitespace-nowrap
"
>
আমাদের প্রতিশ্রুতি
</h2>

<p
className="
mt-1
text-sm
text-gray-600
leading-5
"
>
আমরা অরিজিনাল এবং দ্রুত ডেলিভারি নিশ্চিত করি। 
আপনার সন্তুষ্টিই আমাদের প্রধান লক্ষ্য।
</p>

</div>

</div>


</div>

</div>





{/* ORDER BUTTON FULL WIDTH */}


<div className="mx-5 mt-2">

<button

disabled={ordering}
onClick={async()=>{

if(
  paymentMethod === "bKash" &&
  (!bkashNumber || !bkashTransactionId)
){

  errorToast(
    "Please provide your bKash number and transaction ID"
  );

  return;

}

if(
  paymentMethod === "Nagad" &&
  (!nagadNumber || !nagadTransactionId)
){

  errorToast(
    "Please provide your Nagad number and transaction ID"
  );

  return;

}

setOrdering(true);

try {

const orderData = {

title:
landing.title,


heroImages:
images,


price:
landing.offerPrice > 0
?
landing.offerPrice
:
landing.price,


regularPrice:
landing.price,


quantity,

slug,

customer: formData,

landingId: landing.id,

deliveryCharge: deliveryCharge,

total: total,

  };
  



  const orderId = await createOrder({
  landingId: landing.id,
  landingSlug: slug,

  customerName: formData.name,
  phone: formData.phone,
  address: formData.address,
  thana: formData.thana,
  district: formData.district,
  notes: formData.notes,

  productName: landing.title,
  title: landing.title,
  heroImages: images,
  items: [
  {
    productId: landing.productId || "",
    id: landing.productId || "",
    name: landing.title,
    image: images[0] || "",
    quantity,
    price: orderData.price,
  },
],
  slug: slug,
  quantity,

  price: orderData.price,
  regularPrice: orderData.regularPrice,

  deliveryCharge: orderData.deliveryCharge,
  total: orderData.total,

  status: "Pending",

  paymentMethod,

  paymentStatus:
  (paymentMethod === "bKash" || paymentMethod === "Nagad")
  ?
  "Paid"
  :
  "Pending",

  paymentDetails:
  paymentMethod === "bKash"
  ?
  {
    accountNumber: bkashNumber,
    transactionId: bkashTransactionId,
  }
  :
  paymentMethod === "Nagad"
  ?
  {
    accountNumber: nagadNumber,
    transactionId: nagadTransactionId,
  }
  :
  null,

  createdAt: new Date().toISOString(),
});

await incrementLandingOrders(
  landing.id,
  orderData.total
);

orderData.orderId = orderId;



navigate(`/landing/${slug}/success/${orderId}`);

} catch (error) {

  console.error(error);

  setOrdering(false);

}



}}

style={themeBgStyle}

className="
w-full
text-white
py-2.5
rounded-lg
font-bold
text-lg
text-center
"
>

{ordering ? "অর্ডার হচ্ছে..." : "অর্ডার করুন"}

</button>

</div>


{/* CONTACT US */}

<div
className="
mt-6
bg-gray-50
rounded-lg
p-5
text-center
"
>

<h3
className="
text-base
font-bold
mb-4
"
>
যেকোন প্রয়োজনে যোগাযোগ করুন
</h3>

<div
className="
flex
items-center
justify-center
gap-4
"
>

<a
href={MESSENGER_LINK}
target="_blank"
rel="noreferrer"
aria-label="Messenger"
className="
w-14
h-14
rounded-full
bg-[#0084FF]
text-white
flex
items-center
justify-center
shadow-md
hover:opacity-90
transition
"
>

<FaFacebookMessenger size={24}/>

</a>

{
settings?.whatsapp && (

<a
href={`https://wa.me/${settings.whatsapp?.replace(/\D/g,"")}`}
target="_blank"
rel="noreferrer"
aria-label="WhatsApp"
className="
w-14
h-14
rounded-full
bg-[#25D366]
text-white
flex
items-center
justify-center
shadow-md
hover:opacity-90
transition
"
>

<FaWhatsapp size={26}/>

</a>

)
}

</div>

</div>


{/* RELATED PRODUCTS */}

<div
className="
mt-6
bg-gray-50
rounded-lg
p-5
"
>

<h3
className="
text-lg
text-center
font-black
mb-4
"
>
সম্পর্কিত প্রোডাক্ট
</h3>

<RelatedProducts
currentId={landing.productId}
category={landing.category}
/>

</div>


  
  {/*  MOBILE IMAGE FULLSCREEN */}


{
fullscreen && (

<div
className="
fixed
inset-0
bg-black/90
z-50
flex
items-center
justify-center
p-5
"
>


<button

onClick={()=>setFullscreen(false)}

className="
absolute
top-5
right-5
bg-white
text-black
rounded-full
w-12
h-12
flex
items-center
justify-center
text-xl
"
>

<FiX/>

</button>




<img

src={
activeImage || images[0]
}

alt="fullscreen"

className="
max-h-full
max-w-full
rounded-lg
object-contain
"

/>



</div>

)

}






  

{/* CLOSE PREVIEW CONTAINER */}


</div>

</div>

</div>

</>

);

}
